function pizzaOven(crust, sauce, cheeses, toppings) {
    var pizza = {};
    pizza.crust = crust;
    pizza.sauce = sauce;
    pizza.cheeses = cheeses;
    pizza.toppings = toppings;
    return pizza;
}

var p1 = pizzaOven("deep dish", "traditional", ["mozzarella"], ["pepperoni", "sausage"]);
var p2 = pizzaOven("hand tossed", "marinara", ["mozzarella", "feta"], ["mushrooms", "olives", "onions"]);
var p3 = pizzaOven("neapolitan", "san marzano", ["mozzarella"], ["chorizo, bacon"]);
var p4 = pizzaOven("italian", "san marzano", [""], ["basil"]);

console.log(p1);
console.log(p2);
console.log(p3);
console.log(p4);