function logout(el) {
    if (el.innerText == "login") {
        el.innerText = "logout"
    } else [
        el.innerText = "login"
    ]
}

function hide(el) {
    el.remove();
}

function likes(el) {
    var likes = parseInt(el.innerText);
    el.innerText = likes + 1 + " likes";
    alert('ninja was liked');
}