function hideParent(el) {
    el.parentElement.remove();
}

function primSwap(el) {
    el.src = "assets/img/succulents-2.jpg"
}

function primReturn(el) {
    el.src = "assets/img/succulents-1.jpg"
}