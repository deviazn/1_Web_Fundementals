// Print odds 1-20
// Using a loop write code that will console.log all of the odd values from 1 up to 20.
function getOdds(min, max) {
    let arr = [];
    for (let i = min; i <= max; i++) {
        if (i % 2 == 1) {
            arr.push(i);
        }
    }
    return arr;
}

// Decreasing Multiples of 3
// Using a loop write code that will console.log all of the values that are evenly divisible by 3 from 100 down to 0.
function decreasingMultiplesofThree(min, max) {
    let arr = [];
    for (let i = max; i >= min; i--) {
        if (i % 3 == 0) {
            arr.push(i);
        }
    }
    return arr;
}

// Print the sequence
// Using a loop write code that will console.log the values in this sequence 4, 2.5, 1, -0.5, -2, -3.5.

function loopSeq(start, iter, reps) {
    let arr = [];
    if (iter >= 0) {
        for (let i = start; i <= start + (iter * reps); i += iter) {
            arr.push(i);
        }
    } else {
        for (let i = start; i >= start + (iter * reps); i += iter) {
            arr.push(i);
        }
    }
    return arr;
}

// Sigma
// Write code that will add all of the values from 1-100 onto some variable sum and at the max console.log the result 1 + 2 + 3 + ... + 98 + 99 + 100. We should get back 5050 at the max.
function sigma(min, max) {
    let x = 0;
    for (i = min; i <= max; i++) {
        x += i;
    }
    return x;
}

// Factorial
// Write code that will multiply all of the values from 1-12 onto some variable product and at the max console.log the result 1 * 2 * 3 * ... * 10 * 11 * 12. We should get back 479001600 at the max.
function factorial(min, max) {
    let x = 1;
    for (i = min; i <= max; i++) {
        x *= i;
    }
    return x;
}

// Answer Print
function printAns(arr) {
    for (let i = 0; i < arr.length; i++) {
        console.log(arrdict[i]);
        console.log(arr[i]);
    }
}


//main
odds = getOdds(1, 20);
threes = decreasingMultiplesofThree(0, 100);
seq = loopSeq(4, -1.5, 5);
sig = sigma(1, 100);
fac = factorial(1, 12);

let arr = [];
arr.push(odds);
arr.push(threes);
arr.push(seq);
arr.push(sig);
arr.push(fac);

let arrdict = {
    0: "Print Odds",
    1: "Decreasing Multiples of 3",
    2: "Print the Sequence",
    3: "Sigma",
    4: "Factorial"
}

printAns(arr, arrdict);