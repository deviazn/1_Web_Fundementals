// function fizzBuzz(start, end) {
//     for (let i = start; i <= end; i++) {
//         if (i % 3 == 0 && i % 5 == 0) {
//             console.log("fizzBuzz");
//         } else if (i % 3 == 0) {
//             console.log("Fizz");
//         } else if (i % 5 == 0) {
//             console.log("Buzz");
//         } else {
//             console.log(i);
//         }
//     }
// }

function fizzBuzzArr(start, end) {
    let arr = []
    for (let i = start; i <= end; i++) {
        if (i % 3 == 0 && i % 5 == 0) {
            arr.push("fizzBuzz");
        } else if (i % 3 == 0) {
            arr.push("Fizz");
        } else if (i % 5 == 0) {
            arr.push("Buzz");
        } else {
            arr.push(i);
        }
    }
    return arr;
}

function printArr(array) {
    for (i of array) {
        console.log(i);
    }
}


// fizzBuzz(1, 100);
let array = fizzBuzzArr(1, 100);
printArr(array);
console.log(array);