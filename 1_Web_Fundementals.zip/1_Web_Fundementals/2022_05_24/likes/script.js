function likes(el, num) {
    var likes = document.querySelectorAll(".likes p");
    var likesInt = parseInt(likes[num].innerText)
    if (likesInt == 0) {
        likes[num].innerText = likesInt + 1 + " like"
    } else {
        likes[num].innerText = likesInt + 1 + " likes"
    }
}