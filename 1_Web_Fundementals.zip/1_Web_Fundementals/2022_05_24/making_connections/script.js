function changeFullName(el) {
    var fullName = document.querySelector(".fullname");
    if (fullName.innerText == "Jane Doe") {
        fullName.innerText = "Doe Jane";
    } else {
        fullName.innerText = "Jane Doe";
    }
}

function accBtn(el) {
    el.parentElement.parentElement.remove();
    var numcircles = document.querySelectorAll(".numcircle");
    var req = parseInt(numcircles[0].innerText);
    var con = parseInt(numcircles[1].innerText);
    numcircles[0].innerText = req - 1;
    numcircles[1].innerText = con + 1;
}

function decBtn(el) {
    el.parentElement.parentElement.remove();
    var numcircles = document.querySelectorAll(".numcircle");
    var req  = parseInt(numcircles[0].innerText);
    numcircles[0].innerText = req - 1;
}